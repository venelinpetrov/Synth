class A {
	getSomething() {
		console.log(1);
	}
}