"use strict";

var _classCallCheck = function (instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var A = (function () {
	function A() {
		_classCallCheck(this, A);
	}

	_createClass(A, [{
		key: "getSomething",
		value: function getSomething() {
			console.log(1);
		}
	}]);

	return A;
})();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcmlwdC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7SUFBTSxDQUFDO1VBQUQsQ0FBQzt3QkFBRCxDQUFDOzs7Y0FBRCxDQUFDOztTQUNNLHdCQUFHO0FBQ2QsVUFBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztHQUNmOzs7UUFISSxDQUFDIiwiZmlsZSI6InNjcmlwdC1jb21waWxlZC5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIEEge1xyXG5cdGdldFNvbWV0aGluZygpIHtcclxuXHRcdGNvbnNvbGUubG9nKDEpO1xyXG5cdH1cclxufSJdfQ==